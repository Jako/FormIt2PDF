<?php
/**
 * Default Lexicon Entries for FormIt2PDF
 *
 * @package formit2pdf
 * @subpackage lexicon
 */
$_lang['formit2pdf'] = 'FormIt2PDF';
$_lang['formit2pdf.error_create_pdf'] = 'Der PDF-Anhang konnte nicht erstellt werden!';
$_lang['formit2pdf.heading'] = 'Formular-Übermittlung';
$_lang['formit2pdf.intro'] = 'Sie haben das Formular mit den folgenden Daten ausgefüllt:';
