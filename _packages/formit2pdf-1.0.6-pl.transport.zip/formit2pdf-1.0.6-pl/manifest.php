<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# FormIt2PDF

FormIt hook for sending form submissions as PDF attachment using mPDF
(https://mpdf.github.io/)

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GPLv2

## Features

FormIt2PDF is a snippet to send form submissions as PDF attachment
during FormIt posts.

## Installation

MODX Package Management

## Usage

Install via package manager and use the FormIt hook.

## Documentation

For more information please read the documentation on
https://jako.github.io/FormIt2PDF/

## GitHub Repository

https://github.com/Jako/FormIt2PDF


## Third party licenses

This extra includes third party software, for which we are thankful.

* mpdf/mpdf@v8.3.1 [GPL-2.0-only]
* mpdf/psr-http-message-shim@v2.0.1 [MIT]
* mpdf/psr-log-aware-trait@v2.0.0 [MIT]
* myclabs/deep-copy@1.13.4 [MIT]
* paragonie/random_compat@v9.99.100 [MIT]
* psr/http-message@2.0 [MIT]
* psr/log@1.1.4 [MIT]
* setasign/fpdi@v2.6.7 [MIT]',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.6] - 2026-05-20

### Security

- Update Setasign FPDI dependency to fix a security issue

## [1.0.5] - 2025-09-28

### Fixed

- Fix not translated paths containing {base_path}, {core_path} or {assets_path} in the hook properties

## [1.0.4] - 2025-08-08

### Fixed

- Update Setasign FPDI dependency to fix a security issue

## [1.0.3] - 2024-11-13

### Added

- New pdfStationery property for the FormIt2PDF hook

## [1.0.2] - 2022-03-12

### Fixed

- Fix array values are not parsed in PDF

## [1.0.1] - 2022-09-20

### Added

- New pdfMultiSeparator property for the FormIt2PDF hook
- Combine array values with the string in pdfMultiSeparator property

## [1.0.0] - 2022-09-15

### Added

- Initial release for MODX Revolution
',
    'setup-options' => 'formit2pdf-1.0.6-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd4e487a23a069ab913542b2798b9bbcd',
      'native_key' => 'formit2pdf',
      'filename' => 'modNamespace/ec7e11a107274b6a9ab05c6f8057f174.vehicle',
      'namespace' => 'formit2pdf',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '774f976a83af67821875c7ba6b206ce8',
      'native_key' => 'formit2pdf.debug',
      'filename' => 'modSystemSetting/81dce1d180382186919d868564fd5e9f.vehicle',
      'namespace' => 'formit2pdf',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6c4ef760ad3571232461cd64d1bf73d',
      'native_key' => 'formit2pdf.mode',
      'filename' => 'modSystemSetting/43bd938d4eec65eb931754dff5638d96.vehicle',
      'namespace' => 'formit2pdf',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '061c34f0a4469f7670dab63d1009f33e',
      'native_key' => 'formit2pdf.format',
      'filename' => 'modSystemSetting/bf00f68d6185806f1e172005a423c784.vehicle',
      'namespace' => 'formit2pdf',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '590d3b6b2881ce99eb0e168de513b15f',
      'native_key' => 'formit2pdf.defaultFontSize',
      'filename' => 'modSystemSetting/b59a75efb42dbad668910c00bb36d569.vehicle',
      'namespace' => 'formit2pdf',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '284ef68563f8417829e807a3264e4da4',
      'native_key' => 'formit2pdf.defaultFont',
      'filename' => 'modSystemSetting/b75c40566527a45d9f2f1b7710a2bef4.vehicle',
      'namespace' => 'formit2pdf',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66fc91a9200649e82bf3a1b248c72f44',
      'native_key' => 'formit2pdf.mgl',
      'filename' => 'modSystemSetting/dd0c40d89c16df1564b0d852f99d3230.vehicle',
      'namespace' => 'formit2pdf',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad619817260272782f1fd37057828f03',
      'native_key' => 'formit2pdf.mgr',
      'filename' => 'modSystemSetting/91d70ad3cfb47dfc172da5f5104d42a4.vehicle',
      'namespace' => 'formit2pdf',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4019b3506896c35b3df12499b0fc1222',
      'native_key' => 'formit2pdf.mgt',
      'filename' => 'modSystemSetting/cdc7f6d19f915e0c86ae9312cec9af14.vehicle',
      'namespace' => 'formit2pdf',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'efc661f70d98cbc07e080394e294a5ef',
      'native_key' => 'formit2pdf.mgb',
      'filename' => 'modSystemSetting/bf10eb995518585211365b7c77bc5b94.vehicle',
      'namespace' => 'formit2pdf',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b41d02553f78341bba983ee5679d79d9',
      'native_key' => 'formit2pdf.mgh',
      'filename' => 'modSystemSetting/f2a37dbc2f8c07f8c4b2fba0de32473e.vehicle',
      'namespace' => 'formit2pdf',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4323cc3d25198df688ca1c6033cd19db',
      'native_key' => 'formit2pdf.mgf',
      'filename' => 'modSystemSetting/b5f1af48a5aac47ab745d17e8e1c0590.vehicle',
      'namespace' => 'formit2pdf',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51fc43aa0ecb145d870d6b4e79a11266',
      'native_key' => 'formit2pdf.orientation',
      'filename' => 'modSystemSetting/ec90612007c1e0fb8ff1639a760a7fee.vehicle',
      'namespace' => 'formit2pdf',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91409cda1d3297a2fa999b21af80f9c2',
      'native_key' => 'formit2pdf.customFonts',
      'filename' => 'modSystemSetting/b9f20f91303b296b90a56b4a6ba0dc09.vehicle',
      'namespace' => 'formit2pdf',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ad6c2815c1c37576c0456652e8015b2',
      'native_key' => 'formit2pdf.customFontsFolder',
      'filename' => 'modSystemSetting/07ad103f61b9e71968c060338a4a1312.vehicle',
      'namespace' => 'formit2pdf',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8dc7a99648a778f08d9688ed3983cf15',
      'native_key' => 'formit2pdf.permissions',
      'filename' => 'modSystemSetting/07f9d465738e608dc53182b3eaaed025.vehicle',
      'namespace' => 'formit2pdf',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '46c2d600a7412978723db0f3afdb7459',
      'native_key' => 'formit2pdf.userPassword',
      'filename' => 'modSystemSetting/43e5a71df6db8f3ba9278f1e8a0c6877.vehicle',
      'namespace' => 'formit2pdf',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7a708c1dbd533781a9d7e7437534c8a',
      'native_key' => 'formit2pdf.ownerPassword',
      'filename' => 'modSystemSetting/65a005f64050eceb0529572aa4c82ab5.vehicle',
      'namespace' => 'formit2pdf',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ce9168bd5d27950973f72feb3d51769',
      'native_key' => 'formit2pdf.mPDFMethods',
      'filename' => 'modSystemSetting/3300fd129b8a38166e8779492f0f87dc.vehicle',
      'namespace' => 'formit2pdf',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ec8101c7ccfd6119e083ad7402febda',
      'native_key' => 'formit2pdf.author',
      'filename' => 'modSystemSetting/2e352452a7c7ee66b9528efd8d1ee861.vehicle',
      'namespace' => 'formit2pdf',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '469ecb8f3bb903b67b905311a2270737',
      'native_key' => 'formit2pdf.creator',
      'filename' => 'modSystemSetting/f8eb323b521b9d6f74a00582724a61fb.vehicle',
      'namespace' => 'formit2pdf',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1b5b0e0bac79712523f4487440fd14b',
      'native_key' => 'formit2pdf.textTpl',
      'filename' => 'modSystemSetting/c23d12ef77675321cc624c2316652d71.vehicle',
      'namespace' => 'formit2pdf',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea391da26ffc02f3e1a275e494091206',
      'native_key' => 'formit2pdf.styleTpl',
      'filename' => 'modSystemSetting/ba0b228a306918524e9e0cbe7943054c.vehicle',
      'namespace' => 'formit2pdf',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03c3bf3a648c31a335ea82796b1cbe31',
      'native_key' => 'formit2pdf.stationery',
      'filename' => 'modSystemSetting/0c6ea2cb6a3d268b664d864896126cbd.vehicle',
      'namespace' => 'formit2pdf',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c2dcfbabf1b50dae9a730b62c42877cc',
      'native_key' => NULL,
      'filename' => 'modCategory/8f663ca10e33436e58e71a56cb3bba54.vehicle',
      'namespace' => 'formit2pdf',
    ),
  ),
);