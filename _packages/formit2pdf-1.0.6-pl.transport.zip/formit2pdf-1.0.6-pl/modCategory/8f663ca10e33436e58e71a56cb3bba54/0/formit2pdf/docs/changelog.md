# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.6] - 2026-05-20

### Security

- Update Setasign FPDI dependency to fix a security issue

## [1.0.5] - 2025-09-28

### Fixed

- Fix not translated paths containing {base_path}, {core_path} or {assets_path} in the hook properties

## [1.0.4] - 2025-08-08

### Fixed

- Update Setasign FPDI dependency to fix a security issue

## [1.0.3] - 2024-11-13

### Added

- New pdfStationery property for the FormIt2PDF hook

## [1.0.2] - 2022-03-12

### Fixed

- Fix array values are not parsed in PDF

## [1.0.1] - 2022-09-20

### Added

- New pdfMultiSeparator property for the FormIt2PDF hook
- Combine array values with the string in pdfMultiSeparator property

## [1.0.0] - 2022-09-15

### Added

- Initial release for MODX Revolution
