<?php
/**
 * Default Lexicon Entries for FormIt2PDF
 *
 * @package formit2pdf
 * @subpackage lexicon
 */
$_lang['formit2pdf'] = 'FormIt2PDF';
$_lang['formit2pdf.error_create_pdf'] = 'Could not create the pdf attachment!';
$_lang['formit2pdf.heading'] = 'Form Submission';
$_lang['formit2pdf.intro'] = 'You have filled the form with the following data:';
