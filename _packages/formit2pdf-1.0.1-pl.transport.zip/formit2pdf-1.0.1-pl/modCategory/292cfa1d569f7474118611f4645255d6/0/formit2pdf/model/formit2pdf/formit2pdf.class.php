<?php
/**
 *  FormIt2PDF
 *
 * Copyright 2022 by Thomas Jakobi <office@treehillstudio.com>
 *
 * @package formit2pdf
 * @subpackage classfile
 */

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

/**
 * class FormIt2PDF
 */
class FormIt2PDF extends \TreehillStudio\FormIt2PDF\FormIt2PDF
{
}
